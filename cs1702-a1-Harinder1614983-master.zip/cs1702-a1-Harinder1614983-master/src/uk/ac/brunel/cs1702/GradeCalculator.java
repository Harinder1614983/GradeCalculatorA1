package uk.ac.brunel.cs1702;

public class GradeCalculator {

	//Declare all required Fields here as explained in the worksheet A1. 
	
	public static void main(String[] args) {
	//Implement your program logic here to process the Fields declared above.
	//Feel free to declare additional local variables in the main method.
	//Feel free to create other methods and call them from the main method.
	//Your program will be assessed based on its output as explained in the worksheet A1.	
		
	}
}